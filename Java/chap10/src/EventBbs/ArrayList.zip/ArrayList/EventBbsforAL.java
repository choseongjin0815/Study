package EventBbs.ArrayList;
import java.util.ArrayList;
import chap10.BasicBbsIf;

public class EventBbsforAL implements BasicBbsInterface{
	public EventBbsforAL() {}
	public EventBbsforAL(int idx, String title, String name, String email
			, String startDate, String endDate, String registDate, String contentIdx
			, String content) {
		this.idx = idx;
		this.title = title;
		this.name = name;
		this.email = email;
		this.startDate = startDate;
		this.endDate = endDate;
		this.registDate = registDate;
		this.contentIdx = contentIdx;
		this.content = content;
		
	}
	
	String title;
	String email;
	String name;
	String startDate;
	String endDate;
	String registDate;
	String content;
	String contentIdx;
	int idx;
	
	@Override
	public void bbsList(int pageSize, int pageNo) {
		
	}
	
	
	
	@Override
	public void view(int bbsIdx) {
		
	}
	
	public void printList(ArrayList<EventBbsforAL> post, int pageSize) {
		int pageCnt = 0;
		for(int i = 0; i  < post.size(); i++) {
			if(i==0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>");
			else if(i % pageSize == 0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>" );
			post.get(i).showInfo();

		}
	}
	
	void showInfo() {
		System.out.println(this.idx + " " + this.title + " " + this.name + " " + this.email + " " +
				this.startDate + " " + this.endDate + " " + this.registDate + " " + this.contentIdx + " " + this.content); 
	}
	
}
