package EventBbs.ArrayList;
import java.util.ArrayList;
import java.util.Scanner;
public class CreateEventBbs {

	public static void main(String[] args) 
	{
		int pageCnt = 0;
		int eleNumber = 0; //게시글 개수
		
		EventBbsforAL ebl = new EventBbsforAL();
		ArrayList<EventBbsforAL> post = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("페이지 사이즈를 입력하세요");
		int pageSize = sc.nextInt();
		while(true) {
			
			System.out.println("이벤트 게시판에서 어떤 작업을 하실건가요?");
			
			System.out.println("1. [글등록 || 1]\n2. [검색 || 2]\n3. [글조회 || 3]\n4. [끝내기 || 4]\n5. [더미생성 || 5]\n6. [삭제 || 6]\n7. [수정 || 7]");
			String work = sc.next();
			if(work.equals("글등록") || work.equals("1")) {
				System.out.println("게시글을 몇개 등록하실 건가요?");
				int postNo = sc.nextInt();
				System.out.println("제목 이름 이메일 시작일 종료일 등록일 내용을 입력해주세요");
				for(int i = 0; i < postNo; i++) {
					System.out.print("제목 : ");
					String title = sc.next();
					System.out.print("이름 : ");
					String name = sc.next();
					System.out.print("이메일 : ");
					String email = sc.next();
					System.out.print("시작일 : ");
					String startDate = sc.next();
					System.out.print("종료일 : ");
					String endDate = sc.next();
					System.out.print("등록일 : ");
					String registDate = sc.next();
					System.out.print("내용 : ");
					String content = sc.next();
					System.out.println("=============================="+(i+1)+"=================================");
					eleNumber += 1;
					
					post.add(new EventBbsforAL(eleNumber, title, name, email, startDate, endDate, registDate, "게시글" + eleNumber, content));
					 
				}

			}
			else if ((work.equals("검색") || work.equals("2"))) {
				
				if(eleNumber == 0) {
					System.out.println("게시글이 없으므로 검색을 하지 못합니다!");
					continue;
					} //삽입된 게시글이 없으니 검색도 못함
				
				System.out.println("=========================검색========================");
				int cnt = 0;
//				int searchPageCnt = 0;
				
				System.out.println("어떤 내용에서 검색할거임? (title OR content)");
				String inputColumn = sc.next();
				if(inputColumn.equals("title")) {
					System.out.println("어떤 제목을 검색할거임?");
					String inputTitle= sc.next();
					for(EventBbsforAL item : post) {
						if(item.title.equals(inputTitle)) {		
							if(cnt % pageSize == 0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>" );
							cnt++;
							item.showInfo();				
						}
					}
					pageCnt = 0;
				}
				else if (inputColumn.equals("content")) {
					System.out.println("어떤 컨텐츠를 검색할거임?");
					String inputContent= sc.next();
					for(EventBbsforAL item : post) {
						if(item.content.contains(inputContent)) {
							if(cnt % pageSize == 0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>" );
							cnt++;
							item.showInfo();
						}
					}
					pageCnt = 0;
				}
				
			}
			else if(work.equals("3") || work.equals("글조회")) {
				
				ebl.printList(post, pageSize);
				
//				for(int i = 0; i  < post.size(); i++) {
//					if(i==0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>");
//					else if(i % pageSize == 0) System.out.println(">>>>" + ++pageCnt + "페이지입니다.>>>>" );
//					post.get(i).showInfo();
//	
//				}
//				pageCnt = 0;
			}
			else if(work.equals("4") || work.equals("끝내기")) {
				System.out.println("작업을 종료합니다.");
				break;
			}
			else if(work.equals("5") || work.equals("더미생성")) {
				System.out.println("====================테스트용 더미게시글 생성==========================");
				System.out.println("게시글을 몇개 생성하실 건가요?");
				int cNum = sc.nextInt();
				
				for(int i = 0; i < cNum; i++) {
					eleNumber += 1;
					
					post.add(new EventBbsforAL(eleNumber, "제목"+eleNumber, "이름"+eleNumber, "이메일"+eleNumber,
							"시작일"+eleNumber, "종료일"+eleNumber, "등록일"+eleNumber, "게시글" + eleNumber, "게시글내용"+eleNumber));
				}
			}
			else if(work.equals("6") || work.equals("삭제")) {
				
				if(eleNumber == 0) {
					System.out.println("게시글이 없으므로 삭제를 하지 못합니다!");
					continue;
					} //삽입된 게시글이 없으니 삭제도 못함
				
				System.out.println("삭제할 게시글의 인덱스를 입력해주세요");
				int bIdx = sc.nextInt();
				post.remove(bIdx-1);				
				System.out.println(bIdx + "번째 게시글이 삭제되었습니다.");
				
				
				//삭제한 게시글 이후 인덱스 번호의 게시글 인덱스를 앞으로 이어지게 만들어줌.
				for(int i = (bIdx - 1); i < post.size(); i++ ) {
					post.get(i).idx -= 1;
				}
			}
			else if(work.equals("7") || work.equals("수정")) {
				
				if(eleNumber == 0) {
					System.out.println("게시글이 없으므로 수정을 하지 못합니다!");
					continue;
					} //삽입된 게시글이 없으니 수정도 못함
				
				System.out.println("수정할 컬럼과 인덱스번호를 입력하세요");
				System.out.println("1.제목 2.이름 3.이메일 4.게시글내용");
				System.out.print("column>>>");
				int modifyColumnNo = sc.nextInt();
				System.out.print("idx>>>");
				int modifyIdx = sc.nextInt();
				System.out.print("바뀌게 될 값을 입력해주세요>>>");
				String modifyValue = sc.next();
				if(modifyIdx < post.size()){
					if(modifyColumnNo == 1) {
						post.get(modifyIdx-1).title = modifyValue;
					}
					else if(modifyColumnNo == 2) {
						post.get(modifyIdx-1).name = modifyValue;
					}
					else if(modifyColumnNo == 3) {
						post.get(modifyIdx-1).email = modifyValue;
					}
					else if(modifyColumnNo == 4) {
						post.get(modifyIdx-1).content = modifyValue;
					}
				}
				else {
					System.out.println("존재하는 게시글의 인덱스를 초과하였습니다.");
				}
			}
			
		}
		
	}
		
}
		
	


