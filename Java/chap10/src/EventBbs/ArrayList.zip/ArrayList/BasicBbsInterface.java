package EventBbs.ArrayList;
import java.util.ArrayList;
public interface BasicBbsInterface {
	public abstract void bbsList(int pageSize, int pageNo);
	public abstract void view(int bbsIdx);

}
